from django.test import TestCase, Client
from django.urls import reverse
from django.contrib.auth.models import User, Group

class AuthTests(TestCase):
    def setUp(self):
        self.client = Client()
        self.user = User.objects.create_user(username='testuser', password='12345')
        self.group = Group.objects.create(name='Clientes')
        self.user.groups.add(self.group)
        self.user.save()

    def test_register_view(self):
        response = self.client.get(reverse('registo'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'registo.html')

        response = self.client.post(reverse('registo'), {
            'username': 'newuser',
            'password1': 'newpassword123',
            'password2': 'newpassword123'
        })
        self.assertEqual(response.status_code, 200)  # Redirecionamento após registro bem-sucedido

    def test_login_view(self):
        response = self.client.post(reverse('login'), {
            'username': 'testuser',
            'password': '12345'
        })
        self.assertEqual(response.status_code, 302)
        self.assertRedirects(response, '/')

    def test_logout_view(self):
        self.client.login(username='testuser', password='12345')
        response = self.client.post(reverse('logout'))
        self.assertEqual(response.status_code, 302)

    def test_pagina_protegida_view(self):
        self.client.login(username='testuser', password='12345')
        response = self.client.get(reverse('pagina_protegida'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'pagina_protegida.html')

    def test_perfil_view(self):
        self.client.login(username='testuser', password='12345')
        response = self.client.get(reverse('perfil'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'perfil.html')

    def test_redefinir_senha_view(self):
        self.client.login(username='testuser', password='12345')
        response = self.client.post(reverse('redefinir_senha'), {
            'username': 'testuser',
            'nova_senha': 'newpassword123',
            'confirmar_senha': 'newpassword123'
        })
        self.assertEqual(response.status_code, 302)  # Redirecionamento esperado
        self.user.refresh_from_db()
        self.assertTrue(self.user.check_password('newpassword123'))

    def test_senha_redefinida_sucesso_view(self):
        response = self.client.get(reverse('senha_redefinida_sucesso'))
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, 'registration/senha_redefinida_sucesso.html')
