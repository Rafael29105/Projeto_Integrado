from django.urls import path
from . import views

urlpatterns = [
    path('pagina-protegida/', views.pagina_protegida, name='pagina_protegida'),
    path('registo/', views.registo, name='registo'),
    path('confirmar-logout/', views.confirmar_logout, name='confirmar_logout'),
    path('logout-sucesso/', views.logout_sucesso, name='logout_sucesso'),  # URL para sucesso de logout
    path('perfil/', views.perfil, name='perfil'),  # URL para a página de perfil
    path('redefinir-senha/', views.redefinir_senha_view, name='redefinir_senha'),
    path('senha-redefinida-sucesso/', views.senha_redefinida_sucesso, name='senha_redefinida_sucesso'),
    
]
