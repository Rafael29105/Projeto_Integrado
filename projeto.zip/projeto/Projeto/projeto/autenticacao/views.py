from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect
from django.contrib.auth import login
from .forms import RegistoForm
from django.contrib.auth.models import Group
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.hashers import make_password
from django.contrib import messages

def registo(request):
    if request.method == 'POST':
        form = RegistoForm(request.POST)
        if form.is_valid():
            user = form.save()
            login(request, user)
            return redirect('/')
    else:
        form = RegistoForm()
    return render(request, 'registo.html', {'form': form})

def confirmar_logout(request):
    return render(request, 'confirmar_logout.html')

def logout_sucesso(request):
    return render(request, 'logout_sucesso.html')

@login_required
def pagina_protegida(request):
    return render(request, 'pagina_protegida.html', {'user': request.user})

@login_required
def perfil(request):
    return render(request, 'perfil.html', {'user': request.user})

def register(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()
            
            grupo_clientes = Group.objects.get(name='Clientes')
            user.groups.add(grupo_clientes)
            
            return redirect('login')
        else:
            form = UserCreationForm()
    return render(request, 'registo.html', {'form': form})

def redefinir_senha_view(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        nova_senha = request.POST.get('nova_senha')
        confirmar_senha = request.POST.get('confirmar_senha')

        try:
            user = User.objects.get(username=username)
        except User.DoesNotExist:
            messages.error(request, "Utilizador não encontrado.")
            return render(request, 'redefinir_senha.html')

        # Verifica se as senhas coincidem
        if nova_senha != confirmar_senha:
            messages.error(request, "As senhas não coincidem.")
            return render(request, 'redefinir_senha.html')

        # Atualiza a senha do utilizador
        user.password = make_password(nova_senha)
        user.save()

        messages.success(request, "Senha redefinida com sucesso!")
        return redirect('senha_redefinida_sucesso')

    return render(request, 'redefinir_senha.html')

# View para a página de sucesso após redefinir a senha
def senha_redefinida_sucesso(request):
    return render(request, 'registration/senha_redefinida_sucesso.html')

