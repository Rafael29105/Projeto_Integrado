from django import forms
from .models import Order

class OrderForm(forms.ModelForm):
    class Meta:
        model = Order
        fields = ['customer_name', 'menu_item', 'quantity', 'status']
        labels = {
            'customer_name': 'Nome do Cliente',
            'menu_item': 'Item do Menu',
            'quantity': 'Quantidade',
            'status': 'Estado',
        }