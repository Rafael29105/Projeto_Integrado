from django.core.validators import MinValueValidator
from django.db import models
from menu.models import MenuItem

class Order(models.Model):
    customer_name = models.CharField(max_length=100)
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)
    quantity = models.IntegerField(validators=[MinValueValidator(0)])
    status = models.CharField(max_length=50)

    def __str__(self):
        return f"{self.customer_name} - {self.menu_item.name}"

    @property
    def total_price(self):
        return self.menu_item.price * self.quantity
