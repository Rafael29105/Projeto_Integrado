from django import forms
from .models import Order

# Definindo o formulário para o modelo Order
class OrderForm(forms.ModelForm):
    class Meta:
        # Especifica que o formulário será baseado no modelo Order
        model = Order
        # Define os campos do formulário que serão exibidos
        fields = ['customer_name', 'menu_item', 'quantity', 'status']  # Removemos o campo price
