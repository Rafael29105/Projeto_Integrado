from django.db import models
from menu.models import MenuItem  # Importando o modelo MenuItem

# Define o modelo Order
class Order(models.Model):
    # Campo para o nome do cliente, limitado a 100 caracteres
    customer_name = models.CharField(max_length=100)
    # Campo para a referência ao item do menu, com relacionamento ForeignKey para MenuItem
    menu_item = models.ForeignKey(MenuItem, on_delete=models.CASCADE)  # Relacionamento com MenuItem
    # Campo para a quantidade do item pedido
    quantity = models.IntegerField()
    # Campo para o status do pedido, limitado a 50 caracteres
    status = models.CharField(max_length=50)

    # Método para retornar uma representação em string do pedido
    def __str__(self):
        return f"{self.customer_name} - {self.menu_item.name}"

    # Propriedade para calcular o preço total do pedido
    @property
    def total_price(self):
        return self.menu_item.price * self.quantity  # Calcula o preço total com base na quantidade
